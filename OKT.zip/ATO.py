from random import *
from math import *
import pygame
import os
import json
pygame.init()
win=pygame.display.set_mode((1200,600))
run=True

texts={}
fonts={}
def produce(text="TEXT NOT FOUND",size=20,color=(255,255,255),font="courier new"):
    font_key=str(size)+str(font)
    text_key=str(text)+str(size)+str(color)+str(font)
    if not font_key in fonts:
        fonts[font_key]=pygame.font.SysFont(font,int(size))
    if not text_key in texts:
        texts[text_key]=fonts[font_key].render(str(text),1,color)
    return texts[text_key]
def center(sprite,surface,x,y):
    sprite.set_colorkey((0,0,1))
    surface.blit(sprite,(x-sprite.get_width()/2,y-sprite.get_height()/2))
croll=lambda x:int(-log(random(),x))

Ssheet=pygame.image.load("ATOspritesheet.xcf")
Pieces={}
for root,dirs,files in os.walk(r"ATOdata"):
    for file in files:
        if file.endswith(".json"):
            Pieces.update(json.load(open(f"{root}\\{file}","r")))
for i in Pieces:
    Pieces[i]["Sprite"]=Ssheet.subsurface((Pieces[i]["SpritePos"][0],Pieces[i]["SpritePos"][1],20,20))
    Pieces[i]["LargeSprite"]=pygame.transform.scale(Pieces[i]["Sprite"],(200,200))
    
Piece_pools=[[] for i in range(5)]
for i in Pieces:
    Piece_pools[["Common","Uncommon","Rare","Epic","Legendary"].index(Pieces[i]["Rarity"])].append(i)
menu="Choose Game Size"
click=[False,False,False]
ctimer=[0,0,0]
board_type_names=[
    "Quick",
    "Normal",
    "Long",
    "Epic",
    "Legendary",
    ]
piece_limits=[
    [4,3,2,1,0],    #10
    [5,4,3,2,1],    #15
    [7,5,4,3,1],    #20
    [11,8,5,4,2],   #30
    [15,10,7,5,3],        #40
    ]
def show_piece_choice(rarity,choosing_from=3):
    global run
    print(rarity)
    choosing=True
    #choosing=False
    
    pieces_to_choose=[choice(Piece_pools[rarity]) for i in range(choosing_from)]
    while run and choosing:
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                run=False
        win.fill((0,0,0))
        mouse_pos=pygame.mouse.get_pos()
        mouse_down=pygame.mouse.get_pressed()
        for i in range(3):
            ctimer[i]=mouse_down[i]*(ctimer[i]+1)
            click[i]=(ctimer[i]==1)
        if choosing_from==3:
            for i in range(choosing_from):
                center(Pieces[pieces_to_choose[i]]["LargeSprite"],win,300+i*300,300)
        
        pygame.display.update()
    return 0
#discard pile, p1 deck, p2 deck
deck=[[],[],[]]
for i in range(30):
    board_type_names.append("NOT CREATED YET")
while run:
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
    win.fill((0,0,0))
    mouse_pos=pygame.mouse.get_pos()
    mouse_down=pygame.mouse.get_pressed()
    for i in range(3):
        ctimer[i]=mouse_down[i]*(ctimer[i]+1)
        click[i]=(ctimer[i]==1)
    if menu=="Choose Game Size":
        for i,name in enumerate(board_type_names):
            x_f=i//7
            y_f=i%7
            if 250+x_f*225>mouse_pos[0]>50+x_f*225 and 125+y_f*75>mouse_pos[1]>50+y_f*75:
                pygame.draw.rect(win,(0,255,255),(50+x_f*225,50+y_f*75,200,50),3)
                center(produce(name),win,150+x_f*225,75+y_f*75)
                if click[0]:
                    game_mode=i
                    menu="Drafting Deck 1"
            else:
                pygame.draw.rect(win,(255,255,255),(50+x_f*225,50+y_f*75,200,50),3)
                center(produce(name),win,150+x_f*225,75+y_f*75)
    elif menu=="Drafting Deck 1":
        if len(deck[1])>=sum(piece_limits[game_mode]):
            menu="Waiting For Player 2"
            sequence="Drafting Deck 2"
        else:
            for i in range(5):
                if len(deck[1])<sum(piece_limits[game_mode][:i+1]):
                    break
            deck[1].append(show_piece_choice(i))
    pygame.display.update()
pygame.quit()
